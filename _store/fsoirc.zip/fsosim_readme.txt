
	FSOsims mIRC Addon, Version 1.02
	Designed by Mystery (mystery8@startrekmail.com)
	

1) INTRODUCTION
The FSOsims mIRC Addon isn't really all that complex. Its simply a sound pack and
some Popups that I thought would be useful for FSO Simmers. If you want me to 
add something, email me.

2) INSTALLATION
Put the fsosims.mrc file in your mIRC Directory, and put the sounds in your sound
directory. Then run mIRC and type: /load -rs fsosims.mrc

3) FILES INCLUDED IN THE ZIP ARCHIVE:

fsosims.mrc - The addon file
readme.txt - This file

Sound Files:

abandonship.wav - Data saying "Abandon Ship" (TNG: 11001001)
bluealert.wav - Blue Alert (VOY: The 37's)
entdphot.wav - Enterprise-D firing photon torpedoes (TNG: Half A Life)
fire.wav - USS Defiant firing a Quantum Torpedo (DS9: Changing the Face of Evil)
intruderalert.wav - Enterprise computer saying "Intruder Alert!" (ST: The Motion Picture)
promtorp.wav - USS Prometheus firing one photon torpedo (VOY: Ship In A Bottle)
qnttorp.wav - Enterprise-E firing many quantum torpedoes (ST: First Contact)
redalert.wav - Red Alert siren
simend.wav - Sim Ending Sound
simpause.wav - Sim Pause Sound
simstart.wav - Sim Starting Sound
tranup.wav - Sound of a transporter beam (from Voyager)
voywarp.wav - Sound of Warp Drive engaging (from Voyager)
vyphaser.wav - Sound of a Phaser beam firing (from Voyager)
yellowalert.wav - Yellow Alert siren (ST: The Search for Spock)


For info, requests, etc. email mystery8@startrekmail.com